
import React, { useState } from 'react';
import axios from 'axios';

const Checkout = () => {
    const [pizza, setPizza] = useState({
        base: '',
        sauce: '',
        cheese: '',
        veggies: []
    });
    const [paymentSuccessful, setPaymentSuccessful] = useState(false);

    const handleCheckout = async () => {
        const options = {
            key: 'your_razorpay_test_key',
            amount: 50000, // Example amount
            currency: 'INR',
            name: 'Pizza Delivery',
            description: 'Order your pizza',
            handler: async (response) => {
                const order = await axios.post('/api/orders', { ...pizza, paymentId: response.razorpay_payment_id });
                if (order.status === 200) {
                    setPaymentSuccessful(true);
                }
            }
        };
        const rzp1 = new window.Razorpay(options);
        rzp1.open();
    };

    return (
        <div>
            <h1>Checkout</h1>
            {paymentSuccessful ? (
                <div>Payment successful! Your pizza is on the way.</div>
            ) : (
                <div>
                    <button onClick={handleCheckout}>Pay with Razorpay</button>
                </div>
            )}
        </div>
    );
};

export default Checkout;
