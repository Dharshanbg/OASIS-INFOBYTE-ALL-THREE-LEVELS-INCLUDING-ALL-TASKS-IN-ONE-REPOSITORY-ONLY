import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AdminDashboard = () => {
    const [orders, setOrders] = useState([]);
    const [inventory, setInventory] = useState([]);

    useEffect(() => {
        // Fetch orders and inventory from the backend
        const fetchData = async () => {
            const ordersData = await axios.get('/api/orders');
            const inventoryData = await axios.get('/api/inventory');
            setOrders(ordersData.data);
            setInventory(inventoryData.data);
        };
        fetchData();
    }, []);

    const updateOrderStatus = async (orderId, status) => {
        await axios.put(`/api/orders/${orderId}`, { status });
        // Update the order list after status change
        const updatedOrders = orders.map(order => order._id === orderId ? { ...order, status } : order);
        setOrders(updatedOrders);
    };

    return (
        <div>
            <h1>Admin Dashboard</h1>
            <h2>Orders</h2>
            <ul>
                {orders.map(order => (
                    <li key={order._id}>
                        {order.pizzaName} - {order.status}
                        <button onClick={() => updateOrderStatus(order._id, 'In Kitchen')}>In Kitchen</button>
                        <button onClick={() => updateOrderStatus(order._id, 'Sent to Delivery')}>Sent to Delivery</button>
                    </li>
                ))}
            </ul>

            <h2>Inventory</h2>
            <ul>
                {inventory.map(item => (
                    <li key={item._id}>{item.name}: {item.quantity}</li>
                ))}
            </ul>
        </div>
    );
};

export default AdminDashboard;
