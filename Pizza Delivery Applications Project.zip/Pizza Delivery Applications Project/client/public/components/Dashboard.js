import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Dashboard = () => {
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        const fetchOrders = async () => {
            const response = await axios.get('/api/orders');
            setOrders(response.data);
        };
        fetchOrders();
    }, []);

    return (
        <div>
            <h1>User Dashboard</h1>
            <h2>Your Orders</h2>
            <ul>
                {orders.map(order => (
                    <li key={order._id}>
                        {order.pizzaName} - {order.status}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Dashboard;
