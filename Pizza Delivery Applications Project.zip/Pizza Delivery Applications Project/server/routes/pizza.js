const express = require('express');
const { createOrder } = require('../controllers/pizzaController');
const auth = require('../middlewares/auth');
const router = express.Router();

router.post('/order', auth, createOrder);

module.exports = router;
