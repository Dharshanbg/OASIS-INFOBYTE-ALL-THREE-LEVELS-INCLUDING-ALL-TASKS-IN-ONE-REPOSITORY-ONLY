const mongoose = require('mongoose');

const inventorySchema = new mongoose.Schema({
  base: { type: Number, required: true, default: 100 },
  sauce: { type: Number, required: true, default: 100 },
  cheese: { type: Number, required: true, default: 100 },
  veggies: { type: Number, required: true, default: 100 },
});

inventorySchema.statics.updateStock = async function (items) {
  // Update inventory based on the items used in the order
  const inventory = await this.findOne();
  
  inventory.base -= 1;
  inventory.sauce -= 1;
  inventory.cheese -= 1;
  inventory.veggies -= items.veggies.length;
  
  await inventory.save();
};

module.exports = mongoose.model('Inventory', inventorySchema);
