// Function to show the login form
function showLoginForm() {
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
}

// Function to show the registration form
function showRegisterForm() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
}

// Function to register a new user
function register() {
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;

    if (username === '' || password === '') {
        alert('Please fill in all fields.');
        return;
    }

    if (localStorage.getItem(username)) {
        alert('Username already exists.');
        return;
    }

    localStorage.setItem(username, password);
    alert('Registration successful! You can now login.');
    showLoginForm();
}

// Function to login a user
function login() {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    if (username === '' || password === '') {
        alert('Please fill in all fields.');
        return;
    }

    const storedPassword = localStorage.getItem(username);
    if (storedPassword && storedPassword === password) {
        sessionStorage.setItem('user', username);
        showSecuredPage();
    } else {
        alert('Invalid username or password.');
    }
}

// Function to show the secured page
function showSecuredPage() {
    const user = sessionStorage.getItem('user');
    if (user) {
        document.getElementById('user').innerText = user;
        document.getElementById('login-form').style.display = 'none';
        document.getElementById('register-form').style.display = 'none';
        document.getElementById('secured-page').style.display = 'block';
    }
}

// Function to logout a user
function logout() {
    sessionStorage.removeItem('user');
    document.getElementById('secured-page').style.display = 'none';
    showLoginForm();
}

// Automatically show secured page if user is logged in
window.onload = function() {
    if (sessionStorage.getItem('user')) {
        showSecuredPage();
    } else {
        showLoginForm();
    }
};

