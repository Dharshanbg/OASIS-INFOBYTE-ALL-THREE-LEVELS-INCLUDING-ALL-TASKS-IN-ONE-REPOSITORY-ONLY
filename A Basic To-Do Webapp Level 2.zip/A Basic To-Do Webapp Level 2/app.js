let pendingTasks = [];
let completedTasks = [];

// Function to add a new task
function addTask() {
    const taskInput = document.getElementById('new-task');
    const taskText = taskInput.value.trim();

    if (taskText === '') {
        alert('Please enter a task.');
        return;
    }

    const task = {
        text: taskText,
        createdAt: new Date(),
    };

    pendingTasks.push(task);
    taskInput.value = ''; // Clear input field
    renderTasks();
}

// Function to render pending and completed tasks
function renderTasks() {
    // Render pending tasks
    const pendingList = document.getElementById('pending-list');
    pendingList.innerHTML = '';

    pendingTasks.forEach((task, index) => {
        const taskItem = document.createElement('li');
        taskItem.innerHTML = `
            ${task.text} <small>(Added: ${task.createdAt.toLocaleString()})</small>
            <button class="complete-btn" onclick="markAsComplete(${index})">Complete</button>
            <button class="edit-btn" onclick="editTask(${index})">Edit</button>
            <button class="delete-btn" onclick="deleteTask(${index}, 'pending')">Delete</button>
        `;
        pendingList.appendChild(taskItem);
    });

    // Render completed tasks
    const completedList = document.getElementById('completed-list');
    completedList.innerHTML = '';

    completedTasks.forEach((task, index) => {
        const taskItem = document.createElement('li');
        taskItem.classList.add('completed');
        taskItem.innerHTML = `
            ${task.text} <small>(Completed: ${task.completedAt.toLocaleString()})</small>
            <button class="delete-btn" onclick="deleteTask(${index}, 'completed')">Delete</button>
        `;
        completedList.appendChild(taskItem);
    });
}

// Function to mark a task as complete
function markAsComplete(index) {
    const completedTask = pendingTasks.splice(index, 1)[0];
    completedTask.completedAt = new Date();
    completedTasks.push(completedTask);
    renderTasks();
}

// Function to edit a task
function editTask(index) {
    const newTaskText = prompt('Edit your task:', pendingTasks[index].text);
    if (newTaskText !== null && newTaskText.trim() !== '') {
        pendingTasks[index].text = newTaskText;
        renderTasks();
    }
}

// Function to delete a task
function deleteTask(index, listType) {
    if (listType === 'pending') {
        pendingTasks.splice(index, 1);
    } else if (listType === 'completed') {
        completedTasks.splice(index, 1);
    }
    renderTasks();
}
